
library(survival)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure4_data")

rt=read.table("Disease specific survival.txt",header=T,sep="\t",check.names=F,row.names=1)
rt$futime=rt$futime/365
gene=colnames(rt)[3]

outTab=data.frame()
for(i in unique(rt[,"CancerType"])){
	rt1=rt[(rt[,"CancerType"]==i),]
	cox=coxph(Surv(futime, fustat) ~ rt1[,gene], data = rt1)
	coxSummary = summary(cox)
  coxP=coxSummary$coefficients[,"Pr(>|z|)"]
	outTab=rbind(outTab,
	             cbind(cancer=i,
	                   HR=coxSummary$conf.int[,"exp(coef)"],
	                   HR.95L=coxSummary$conf.int[,"lower .95"],
	                   HR.95H=coxSummary$conf.int[,"upper .95"],
			           pvalue=coxP) )
}
write.table(outTab,file="cox.result_Disease specific survival.txt",sep="\t",row.names=F,quote=F)   

#Notes: for OS, DSS, PFI, and DFI, the code are the same.