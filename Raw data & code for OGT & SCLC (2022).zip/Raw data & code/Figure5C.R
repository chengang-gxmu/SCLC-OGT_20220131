
library(ggplot2)
library(ggpubr)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure5_data")
pFilter=0.05         

exp=read.table("Figure5C_data1.txt", header=T,sep="\t",row.names=1,check.names=F)
exp=exp[exp$Type=="Tumor",]
gene="OGT"
TME=read.table("Figure5C_data2.txt", header=T,sep="\t",row.names=1,check.names=F)
sameSample=intersect(row.names(TME),row.names(exp))
TME=TME[sameSample,]
exp=exp[sameSample,]

    exp1=exp[(exp[,"CancerType"]=="KICH"),]
    TME1=TME[(TME[,"CancerType"]=="KICH"),]
    y=as.numeric(exp1[,1])
		x=as.numeric(TME1[,"B_cell"])
		df1=as.data.frame(cbind(x,y))

		ggplot(df1, aes(x, y)) + 
			xlab(paste0("B_cell"," level"))+ylab(paste0(gene," Log2(TPM+1)"))+
			ggtitle("KICH")+
		    geom_point()+ geom_smooth(method="lm") + theme_bw()+
		    stat_cor(method = 'spearman', aes(x =x, y =y),cor.coef.name ="rho")
