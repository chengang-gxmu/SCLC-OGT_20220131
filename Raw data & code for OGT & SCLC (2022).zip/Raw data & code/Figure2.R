library(tidyverse)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure2_data")

rt=read.table("for_Figure2_data.txt",sep="\t",header=T,check.names=F)

rt=rt[order(rt$Platform),]
nm=data.frame(table(rt[,"Platform"]));colnames(nm)=c("Platform","Sample_number")

Platform_Platform=c(rep(nm[1,1], nm[1,2]))
  for (i in 2:nrow(nm)) {
    Platform_Platform=c(Platform_Platform,c(rep(nm[i,1], nm[i,2])))
  }
data3 = data.frame(rt,Platform_Platform)

empty_bar2=4
to_add2 = data.frame(matrix(NA, empty_bar2*nlevels(data3$Platform), ncol(data3)))
colnames(to_add2) = colnames(data3)
to_add2$Platform=rep(levels(data3$Platform), each=empty_bar2)
data4 = rbind(data3, to_add2)
data4 = data4 %>% arrange(Platform)
data4=data4[order(data4$Platform),]
data4$id=seq(1, nrow(data4))

label_rt = data4
number_of_bar2 = nrow(label_rt)
angle2= 90 - 360 * (label_rt$id-0.5) /number_of_bar2
label_rt$hjust<-ifelse(angle2 < -90, 1, 0)
label_rt$angle<-ifelse(angle2 < -90, angle2 +180, angle2)

ggplot(data4, aes(x=as.factor(id), y=Sample_number, fill=Platform)) +
  geom_bar(stat="identity", alpha=1) +
  ylim(-150,150) +
  theme_minimal() +
  theme(
    legend.position = "right",
    axis.text = element_blank(),
    axis.title = element_blank(),
    panel.grid = element_blank(),
    plot.margin = unit(rep(-1,4), "cm")
  ) +
  coord_polar() +
  geom_text(data=label_rt, aes(x=id, y=Sample_number + 20, label=Cohorts, hjust=hjust), 
            color="black",fontface="bold",alpha=0.6, size=2.5, 
            angle= label_rt$angle, inherit.aes = FALSE )
