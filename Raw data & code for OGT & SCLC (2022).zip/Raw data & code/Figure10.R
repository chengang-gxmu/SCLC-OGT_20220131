
#library(dplyr)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure10_data")

library("org.Hs.eg.db")#;library(GOplot);library(Hmisc);
library(clusterProfiler)
rt=read.table("up-cegs.txt",sep="\t",check.names=F,header=T)
genes=as.vector(rt[,1])
entrezIDs <- mget(genes, org.Hs.egSYMBOL2EG, ifnotfound=NA)
entrezIDs <- as.character(entrezIDs)
out=cbind(rt,entrezID=entrezIDs)
write.table(out,file="id.txt",sep="\t",quote=F,row.names=F)

rt=read.table("id.txt",sep="\t",header=T,check.names=F)
rt=rt[is.na(rt[,"entrezID"])==F,]
geneFC=rt$SMD
gene=rt$entrezID
names(geneFC)=gene


  kk <- enrichGO(gene = gene,OrgDb = org.Hs.eg.db,ont="BP",pAdjustMethod = "none",pvalueCutoff =0.05,readable=T)
  rmredunego <- simplify(kk, cutoff=0.7, by="p.adjust", select_fun=min)
  write.table(rmredunego,file="GO-BP.txt",sep="\t",quote=F,row.names = F)

library(ReactomePA)
React <- enrichPathway(gene=gene,organism = "human",pvalueCutoff=0.05)
Reactcome<- setReadable(React, OrgDb = org.Hs.eg.db, keyType="ENTREZID")
write.table(Reactcome,file="ReactomePA.txt",sep="\t",quote=F,row.names=F,col.names=T)
