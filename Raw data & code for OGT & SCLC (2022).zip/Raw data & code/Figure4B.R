library(survminer);library(survival)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure4_data")
        nameList <- "Disease specific survival.txt"
        rt=read.table("Disease specific survival.txt",header=T,sep="\t",check.names=F,row.names=1)
        gene="OGT"
        rt$Survival_time=rt$futime/365
        rt$status=rt$fustat
        CancerType="KICH"
                rtt=subset(rt,CancerType=="KICH")      
        res.cut <- surv_cutpoint(rtt, time = "Survival_time", event = "status",
                                 variables = c(gene))  
        summary(res.cut)
        res.cat <- surv_categorize(res.cut)
        head(res.cat)
        a=res.cat[,gene]=="low";n=length(res.cat[,gene])
        fit <- survfit(Surv(Survival_time, status) ~a, data = res.cat)
        diff <- survdiff(Surv(Survival_time, status) ~a, data = res.cat)
        ggsurvplot(fit, title=paste0("DSS"," (",CancerType," )"),
                          xlab = "Time (Years)",
                          pval = T,
                          risk.table = TRUE)
