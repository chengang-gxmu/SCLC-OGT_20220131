library(ggplot2)
library(ggsignif)

rm(list = ls())

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure7_data\\OGT_mRNA")
uploaded<- read.table("OGT-GPL96",sep="\t",header=T,check.names=F)

uploaded[,1]=gsub("T", "Tumor", uploaded[,1])
uploaded[,1]=gsub("N", "Non-Tumor", uploaded[,1])

ggplot(data=uploaded,aes(x=ID,y=OGT,fill=ID))+ 
  geom_signif(map_signif_level=TRUE,test='wilcox.test',comparisons = list(c("Non-Tumor", "Tumor")))+
  geom_violin(trim=FALSE,color='black')+
  geom_boxplot(color='black') +
  stat_summary(geom='point')
