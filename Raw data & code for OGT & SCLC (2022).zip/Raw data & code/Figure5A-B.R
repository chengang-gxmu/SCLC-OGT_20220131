
library(pROC)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure5_data")

rt<- read.table("Figure5A-B_data.txt",sep="\t",header=T,check.names=F)
uploaded=rt[rt$`Cancer and samples`=="ACC",]

  uploaded[uploaded=="N"]=0;uploaded [uploaded=="T"]=1
  rocobj <- roc(uploaded$Group, uploaded$`OGT expression`, levels = c(0,1),
                direction='<')
  AUC=rocobj$auc[[1]]
  if (AUC<0.5) {
    rocobj <- roc(uploaded$Group, uploaded$`OGT expression`, levels = c(0,1),
                  direction='>')}
         plot(rocobj,
              legacy.axes = TRUE,print.auc=TRUE, auc.polygon=TRUE,
              main="ACC",cex.main=1,
              xlim=c(1,0),ylim=c(0,1),
              thresholds="best", 
              print.thres="best")

Sensitivity=coords(rocobj, "best")$sensitivity
Specificity=coords(rocobj, "best")$specificity
Cutoff=coords(rocobj, "best")$threshold
AUC=rocobj$auc[[1]]
TP=table((uploaded$Group)=="1")[[2]]*Sensitivity
TN=table((uploaded$Group)=="0")[[2]]*Specificity
FP=table((uploaded$Group)=="0")[[2]]-TN
FN=table((uploaded$Group)=="1")[[2]]-TP


#For sROC, the code of Stata 15.0 was: midas tp fp fn tn, sroc(both)