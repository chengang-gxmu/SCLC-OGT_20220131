
library(fmsb) 

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure6_data")

exp=read.table("TMB.txt", header=T,sep="\t",row.names=1,check.names=F)

outTab=data.frame()

  exp1=exp[(exp[,"CancerType"]=="COAD"),]
  x=as.numeric(exp1[,2])
  y=as.numeric(exp1[,1])
  corT=cor.test(x,y,method="pearson")
  cor=corT$estimate
  pValue=corT$p.value
  sig=ifelse(pValue<0.001,"***",ifelse(pValue<0.01,"**",ifelse(pValue<0.05,"*"," ")))
  outTab=rbind(outTab,cbind(CancerType="COAD",cor=cor,pValue=pValue,sig))
  
write.table(outTab,file="corStat_TMB COAD.txt",sep="\t",row.names=F,quote=F)

