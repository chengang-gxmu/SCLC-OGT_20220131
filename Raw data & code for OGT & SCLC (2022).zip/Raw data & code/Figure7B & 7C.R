
library(metafor)
library(meta)

setwd("C:\\Users\\lgs\\Desktop\\Raw data\\Figure7_data\\SMD&Funnel")

rt=read.table("OGT SMD forest.txt",header=T,sep="\t",check.names=F)           

meta1 <-metacont(n.e, mean.e, sd.e, n.c, mean.c, sd.c, 
                 data=rt, studlab=studlab,comb.fixed = FALSE,comb.random = TRUE,sm="SMD")#,byvar=mm

forest(meta1)#forest plot


metabia=metabias(meta1,method.bias="rank")
funnel(meta1,pch=19)#begg's plot

